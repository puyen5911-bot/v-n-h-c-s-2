---
name: Digital Literature 12
colors:
  surface: '#fff8f8'
  surface-dim: '#eed4d9'
  surface-bright: '#fff8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff0f2'
  surface-container: '#ffe8ed'
  surface-container-high: '#fce2e7'
  surface-container-highest: '#f6dce2'
  on-surface: '#26181c'
  on-surface-variant: '#594048'
  inverse-surface: '#3c2c30'
  inverse-on-surface: '#ffecef'
  outline: '#8c6f78'
  outline-variant: '#e0bec7'
  surface-tint: '#b80068'
  primary: '#b40066'
  on-primary: '#ffffff'
  primary-container: '#d9237f'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb0ca'
  secondary: '#9e3a64'
  on-secondary: '#ffffff'
  secondary-container: '#ff88b4'
  on-secondary-container: '#791c46'
  tertiary: '#006c08'
  on-tertiary: '#ffffff'
  tertiary-container: '#00880d'
  on-tertiary-container: '#f8fff0'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9e3'
  primary-fixed-dim: '#ffb0ca'
  on-primary-fixed: '#3e001f'
  on-primary-fixed-variant: '#8d004e'
  secondary-fixed: '#ffd9e3'
  secondary-fixed-dim: '#ffb0ca'
  on-secondary-fixed: '#3e001f'
  on-secondary-fixed-variant: '#80224c'
  tertiary-fixed: '#82fd71'
  tertiary-fixed-dim: '#65e058'
  on-tertiary-fixed: '#002201'
  on-tertiary-fixed-variant: '#005304'
  background: '#fff8f8'
  on-background: '#26181c'
  surface-variant: '#f6dce2'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system is tailored for a next-generation Grade 12 National High School Exam (THPT Quốc Gia 2027) literature preparation platform based on the "Kết Nối Tri Thức" curriculum. It merges poetic literary sensibilities with modern, distraction-free study software ergonomics.

### Personality & Emotional Response
- **Serene & Encouraging:** Alleviates exam anxiety through breathable white space, soft flora-tinted tones, and delicate visual softness.
- **Literary Elegance with Tech Fluency:** Balances the emotional richness of prose and poetry with the crisp clarity of modern digital tools.
- **Cognitive Clarity:** Ensures long-form reading comfort, deliberate focus for essay deconstructions, and frictionless navigation across literary eras and themes.

### Design Style: Soft Modern Minimalist with Tactile Pastel Nuances
The aesthetic draws from contemporary minimal SaaS mixed with editorial warmth. It emphasizes airy canvas spreads, plush pill-shaped controls, subtle translucent magenta/green blurs, and bold deep typography that anchors literary texts firmly on the page.

## Colors

The palette transforms intensive exam study into a restorative, focused ritual. Light mode serves as the primary ground to replicate high-grade book paper tinted with subtle morning warmth.

### Functional Roles
- **Primary (`#DD2782` - Vibrant Magenta):** Anchors primary calls-to-action, active exam states, progress indicators, and key thematic badges.
- **Secondary (`#BD537D` - Dusty Rose):** Reserved for highlights, poetic annotations, success pulses, and motivational badges.
- **Tertiary (`#00940F` - Emerald Green):** Powers supporting actions, active tab borders, secondary tags, and progress bar gradients.
- **Neutral Foreground (`#877277` - Muted Slate Brown):** Delivers WCAG-compliant legibility across long-form literary analyses and critique excerpts, eliminating the harshness of stark pitch-black.
- **Canvas & Surface Grounds (`#FFFFFF`, `#FAFAFA`, `#FDF2F8`, `#F5F3FF`):** Multi-layered neutral bases with ultra-soft magenta and green washes that isolate work modules without rigid divider lines.

## Typography

Typography establishes an effortless hierarchy between study metadata and contemplative literary body text.

### Font Pairing Logic
- **Plus Jakarta Sans (Headings & Labels):** Soft, rounded geometric letterforms give section headers, essay prompts, and navigation elements an approachable, youthful character.
- **Inter (Body & Analysis):** Highly legible neutral grotesque with tall x-height, engineered for fatigue-free reading across lengthy prose passages, critical arguments, and side-by-side rubrics.

### Hierarchy & Editorial Rules
- Literary quotations and excerpts within lessons are rendered in `body-lg` with an increased line height (`30px`) and italic style to provide comfortable pacing.
- Section tags, year markers (e.g., "Kỳ thi 2027"), and chapter badges leverage `label-md` or `label-sm` in all-caps with generous tracking (`0.02em - 0.04em`).

## Layout & Spacing

The layout philosophy centers on open, breathable spaces reminiscent of high-end editorial magazines. This deliberate spaciousness prevents visual fatigue during multi-hour review sessions.

### Grid & Form Factors
- **Desktop (1024px+):** 12-column fluid grid capped at `1280px` max-width. Lesson reading views adopt an offset 8-column center column with a 4-column persistent study rail (mind maps, outlines, quick quiz prompts).
- **Tablet (768px - 1023px):** 8-column fluid grid with collapsible drawers for lesson rubrics. Gutter is kept at `1.25rem`.
- **Mobile (< 768px):** Single-column stacked reading flow with bottom sheet utilities. Gutter scales down to `1rem` with `1.25rem` page margins.

### Rhythmic Padding
- Group literary units into rounded container pods padded generously with `space-lg` to `space-xl`.
- Inter-paragraph distance inside analytical essays adheres strictly to `space-md` (`1rem`) to keep narrative rhythm intact.

## Elevation & Depth

Visual depth is achieved through translucent color tints and diffused ambient shadows, avoiding heavy drops or dark grays.

### Depth Hierarchy
- **Level 0 (Flat Base):** Canvas background (`#FAFAFA` or `#F8FAFC`) with subtle atmospheric ambient gradients of magenta and soft green at the header zone.
- **Level 1 (Card & Module Resting):** Pure white background (`#FFFFFF`) with a delicate perimeter border (`rgba(189, 83, 125, 0.15)` or `rgba(221, 39, 130, 0.08)`) and an ultra-soft tinted shadow: `0 8px 24px -4px rgba(221, 39, 130, 0.05), 0 2px 6px -1px rgba(189, 83, 125, 0.04)`.
- **Level 2 (Hover / Active Cards & Dropdowns):** Subtle upward translation (`-2px`) with an expanded bloom shadow: `0 16px 32px -6px rgba(221, 39, 130, 0.10), 0 4px 12px -2px rgba(189, 83, 125, 0.08)`.
- **Level 3 (Sticky Study Bars, Modals, Audio Players):** Semi-opaque frosted glass (`rgba(255, 255, 255, 0.85)` with `backdrop-filter: blur(16px)`), framed with a glowing border of `rgba(243, 232, 255, 0.8)`.

## Shapes

The design system employs a soft, comforting shape scale with exaggerated pill surfaces for interactive targets and generous rounded corners for content modules.

### Token Application
- **Base Curves (`0.5rem` / `8px`):** Nested child items, code/sample blocks, internal inputs.
- **Container Pods (`rounded-lg` - `1rem` / `16px` & `rounded-xl` - `1.5rem` / `24px`):** Essay containers, sample work comparison splits, quiz panels.
- **Pill Geometry (`9999px`):** CTAs, search bars, topic filter tags, author avatar outlines, and timer badges.

## Components

### Buttons
- **Primary:** Gradient fill from `#DD2782` to `#BD537D`, white text, pill-shaped (`rounded-full`), padded `12px 28px`. Hover produces an ambient magenta glow (`box-shadow: 0 8px 20px rgba(221, 39, 130, 0.3)`).
- **Secondary / Soft:** Tinted background (`#F5F3FF`), deep slate text (`#877277`). On hover, shifts to `#E9D5FF`.
- **Tertiary (Ghost):** Transparent background, slate text (`#877277`), with soft magenta outline on focus.

### Chips & Filter Tags
- Height of `32px` to `36px`, pill-shaped.
- Inactive: Background `#FFFFFF`, border `1px solid #F5F3FF`, text `#877277`.
- Active: Background `#FDF2F8`, border `1px solid #BD537D`, text `#DD2782`, with an optional mini pastel dot marker.

### Cards (Literary Work / Essay Prompt)
- Background `#FFFFFF` with `rounded-2xl` (`1.5rem`) styling.
- Border: `1px solid rgba(243, 232, 255, 0.8)`.
- Features an interior top accent banner wash (soft magenta or green tint) representing the literary genre (Thơ, Truyện ngắn, Ký, Nghị luận).

### Input Fields & Essay Text Areas
- Background `#FAFAFA`, framed with `1.5px solid #E9D5FF`, `rounded-xl`.
- Focus state: Surface transitions to `#FFFFFF`, border shifts to `#DD2782` with an outer ring glow of `0 0 0 4px rgba(189, 83, 125, 0.15)`. Placeholder styled in muted slate (`#87727766`).

### Checkboxes & Radio Buttons
- Rounded checkbox (`6px` radius) and circular radio.
- Inactive: Border `2px solid #D8B4FE`, white background.
- Selected: Solid `#DD2782` background with crisp white checkmark or center pip.

### Literary Specific Components
- **Bilingual / Comparative Reading Split:** A dual-column card system with synchronized scrolling for original text alongside annotated rhetorical devices.
- **Essay Rubric Progress Bar:** Multi-stop progress indicator utilizing a gradient (`#BD537D` to `#DD2782`) housed within a soft pill trough (`#F5F3FF`).
- **Quote Callout Card:** Left border marked by a solid `4px` strip of `#BD537D`, set against an ivory-magenta background (`#FAF5FF`), elevating classic quotations.